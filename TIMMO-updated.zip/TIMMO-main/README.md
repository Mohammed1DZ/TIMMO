# TIMMO Immobilier Dashboard

## Project Setup

1. Clone the project:
   ```bash
   git clone [REPO_LINK]
   cd timmo-dashboard
   npm install
   ```

2. Run the project locally:
   ```bash
   npm start
   ```

3. Test Netlify functions locally:
   ```bash
   netlify dev
   ```

4. Deploy using Netlify by connecting this project via GitHub.

